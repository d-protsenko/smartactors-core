User's feature directory.
Each feature must be in separated directory and contains config.json file.