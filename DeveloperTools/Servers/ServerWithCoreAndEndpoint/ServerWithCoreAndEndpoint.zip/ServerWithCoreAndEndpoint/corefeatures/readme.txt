Load needed feature from archiva features repository (http://archiva.smart-tools.info/#browse~smartactors-features/info.smart_tools.smartactors) and unzip to the current directory.
Configure config.json.

Please, don't forget to look to the feature config.json file for getting information about dependencies between features.