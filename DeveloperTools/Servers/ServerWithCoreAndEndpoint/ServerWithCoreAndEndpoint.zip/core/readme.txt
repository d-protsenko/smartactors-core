Load core-pack.zip from archiva feature repository (http://archiva.smart-tools.info/#browse~smartactors-features/info.smart_tools.smartactors) and extract to current directory.

Direct link on core-pack.zip - https://archiva.smart-tools.info/repository/smartactors-features/info/smart_tools/smartactors/core-pack/0.2.0-SNAPSHOT/core-pack-0.2.0-20161005.114647-1.zip